# Client

This client was forked from the (Stripe
Python)[https://github.com/stripe/stripe-python] bindings.
